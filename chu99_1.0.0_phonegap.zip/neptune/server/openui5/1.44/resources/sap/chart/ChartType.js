/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(function(){"use strict";var C={Bar:"bar",Column:"column",Line:"line",Combination:"combination",Pie:"pie",Donut:"donut",Scatter:"scatter",Bubble:"bubble",Heatmap:"heatmap",Bullet:"bullet",VerticalBullet:"vertical_bullet",StackedBar:"stacked_bar",StackedColumn:"stacked_column",StackedCombination:"stacked_combination",HorizontalStackedCombination:"horizontal_stacked_combination",DualBar:"dual_bar",DualColumn:"dual_column",DualLine:"dual_line",DualStackedBar:"dual_stacked_bar",DualStackedColumn:"dual_stacked_column",DualCombination:"dual_combination",DualHorizontalCombination:"dual_horizontal_combination",DualStackedCombination:"dual_stacked_combination",DualHorizontalStackedCombination:"dual_horizontal_stacked_combination",PercentageStackedBar:"100_stacked_bar",PercentageStackedColumn:"100_stacked_column",PercentageDualStackedBar:"100_dual_stacked_bar",PercentageDualStackedColumn:"100_dual_stacked_column",Waterfall:"waterfall",HorizontalWaterfall:"horizontal_waterfall"};return C;},true);
