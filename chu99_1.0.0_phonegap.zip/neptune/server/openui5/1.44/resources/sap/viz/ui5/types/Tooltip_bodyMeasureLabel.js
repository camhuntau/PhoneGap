/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var T=B.extend("sap.viz.ui5.types.Tooltip_bodyMeasureLabel",{metadata:{library:"sap.viz",properties:{color:{type:"string",defaultValue:'#666666'}}}});return T;});
