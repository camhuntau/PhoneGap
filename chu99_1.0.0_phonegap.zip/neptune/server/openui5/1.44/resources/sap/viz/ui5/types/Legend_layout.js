/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var L=B.extend("sap.viz.ui5.types.Legend_layout",{metadata:{library:"sap.viz",properties:{position:{type:"sap.viz.ui5.types.Legend_layout_position",defaultValue:sap.viz.ui5.types.Legend_layout_position.right},priority:{type:"int",defaultValue:1,deprecated:true}}}});return L;});
