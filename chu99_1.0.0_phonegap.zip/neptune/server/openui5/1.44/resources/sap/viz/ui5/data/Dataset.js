/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/ui/core/Element','sap/viz/library'],function(E,l){"use strict";var D=E.extend("sap.viz.ui5.data.Dataset",{metadata:{"abstract":true,library:"sap.viz"}});return D;});
