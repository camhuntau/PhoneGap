/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var R=B.extend("sap.viz.ui5.types.RootContainer_layout",{metadata:{library:"sap.viz",properties:{adjustPolicy:{type:"string",deprecated:true},padding:{type:"int",defaultValue:24},paddingTop:{type:"int"},paddingLeft:{type:"int"},paddingRight:{type:"int"},paddingBottom:{type:"int"},vgap:{type:"int",defaultValue:8,deprecated:true},hgap:{type:"int",defaultValue:8,deprecated:true},hideAxisTitleFirst:{type:"boolean",defaultValue:true,deprecated:true}}}});return R;});
