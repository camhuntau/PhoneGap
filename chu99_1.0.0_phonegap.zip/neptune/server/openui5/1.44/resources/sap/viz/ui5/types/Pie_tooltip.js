/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var P=B.extend("sap.viz.ui5.types.Pie_tooltip",{metadata:{library:"sap.viz",properties:{visible:{type:"boolean",defaultValue:true},valueFormat:{type:"string",defaultValue:'n',deprecated:true},percentageFormat:{type:"string",defaultValue:'.0%',deprecated:true},formatString:{type:"string[]",defaultValue:null}}}});return P;});
