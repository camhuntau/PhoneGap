/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var a=B.extend("sap.viz.ui5.types.Background_border_left",{metadata:{library:"sap.viz",properties:{visible:{type:"boolean",defaultValue:true}}}});return a;});
