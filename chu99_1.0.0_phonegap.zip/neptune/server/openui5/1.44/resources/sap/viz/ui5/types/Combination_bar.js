/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var C=B.extend("sap.viz.ui5.types.Combination_bar",{metadata:{library:"sap.viz",properties:{isRoundCorner:{type:"boolean",defaultValue:false,deprecated:true}}}});return C;});
