/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var P=B.extend("sap.viz.ui5.types.Pie_animation",{metadata:{library:"sap.viz",properties:{dataLoading:{type:"boolean",defaultValue:true},dataUpdating:{type:"boolean",defaultValue:true},resizing:{type:"boolean",defaultValue:true}}}});return P;});
