/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(function(){"use strict";var P={render:function(r,c){r.write("<div");r.writeControlData(c);r.writeClasses();r.writeStyles();r.write('>');r.write('</div>');}};return P;},true);
