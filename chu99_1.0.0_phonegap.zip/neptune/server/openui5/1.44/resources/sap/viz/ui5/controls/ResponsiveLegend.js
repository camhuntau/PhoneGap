/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define([],function(){var R=function(){throw new Error();};R.createInstance=function(c){var r=jQuery.sap.newObject(this.prototype);r._oLegendControl=c;return r;};R.prototype._oLegendControl=undefined;R.prototype.show=function(){};R.prototype.hide=function(){};R.prototype.setOpenBy=function(o){};return R;},true);
